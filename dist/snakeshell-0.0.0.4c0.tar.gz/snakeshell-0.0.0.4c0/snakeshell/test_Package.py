import snakeshell

print(snakeshell.sample(10))