import os

def Command(command):
    os.system(command)